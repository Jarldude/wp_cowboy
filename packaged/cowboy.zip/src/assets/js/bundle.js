import $ from 'jquery';
import './components/slider';

$('body').click(()=>{
    alert(true);
})