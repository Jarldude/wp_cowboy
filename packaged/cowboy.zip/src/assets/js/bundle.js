console.log('bundle is live');
import $ from 'jquery';

import './components/slider';
import './components/navigation';
import './customize-preview';
