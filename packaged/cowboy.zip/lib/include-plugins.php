<?php

require_once get_template_directory() . '/lib/class-tgm-plugin-activation.php';
add_action( 'tgmpa_register','cowboy_register_required_required_plugins');


function cowboy_register_required_required_plugins(){
    $plugins = array(
        array(
            'name'=> 'cowboy metaboxes',
            'slug'=> 'cowboy-metaboxes',
            'source'=> get_template_directory_uri() . '/lib/plugins/cowboy-metaboxes.zip',
            'required'=> true,
            'version'=> '1.0.0',
            'force_activation'=> false,
            'force_deactivation'=> false
        )
    );

    $config = array(

    );

    tgmpa($plugins, $config);
}