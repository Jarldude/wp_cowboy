<?php 

    function _themaname_customize_register( $wp_customize ){


        /*################################# PARTIAL REFRESH SETTINGS ###############################*/
        $wp_customize->get_setting('blogname')->transport = 'postMessage';

        $wp_customize->selective_refresh->add_partial('blogname', array(
            'selector' => '.c-header__blogname',
            'container_inclusive'=> false,
            'render_callback' => function(){
                bloginfo('name');
            }
        ));

        $wp_customize->selective_refresh->add_partial('cowboy_footer_partial', array(
            'settings' => array('cowboy_footer_bg', 'cowboy_footer_layout'),
            'selector' => '#footer',
            'container_inclusive'=> false,
            'render_callback' => function(){
                get_template_part( 'template-parts/footer/widgets' );
                get_template_part( 'template-parts/footer/info' );
            }
        ));





        /*################################# GENARAL SETTINGS ###############################*/
        $wp_customize->add_section('cowboy_general_options', array(
            'title' =>  esc_html__( 'General Theme Options', 'cowboy'),
            'description' => esc_html__( 'You can change General theme options here.', 'cowboy'),
        ));

        $wp_customize->add_setting('cowboy_accent_colour', array(
            'default' => '#20ddae',
            'transport' => 'postMessage',
            'sanitize_callback' => 'sanitize_hex_color'
            
        ));

        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'cowboy_accent_colour',
        array(
            'label'=>__('Accent Colour', 'cowboy'),
            'section' => 'cowboy_general_options'
        )));




        /*################################# FOOTER SETTINGS ###############################*/

        $wp_customize->add_section('cowboy_footer_options', array(
            'title' =>  esc_html__( 'Footer Options', 'cowboy'),
            'description' => esc_html__( 'You can change footer options from here.', 'cowboy'),
            'priority' => 30
        ));

        $wp_customize->add_setting('cowboy_site_info', array(
            'default' => '',
            'sanitize_callback' => 'cowboy_sanitize_site_info',
            'transport' => 'postMessage'
        ));

        $wp_customize->add_control('cowboy_site_info', array(
            'type' => 'text',
            'label' => esc_html__( 'Site info', 'cowboy'),
            'section' => 'cowboy_footer_options',
        ));



        $wp_customize->add_setting('cowboy_footer_bg', array(
            'default' => 'dark',
            'sanitize_callback' => 'cowboy_sanitize_footer_bg',
            'transport' => 'postMessage'
        ));

        $wp_customize->add_control('cowboy_footer_bg', array(
            'type' => 'select',
            'label' => esc_html__( 'Footer Background', 'cowboy'),
            'choices' => array(
                'light' => esc_html__('Light', 'cowboy'),
                'dark' => esc_html__('Dark', 'cowboy'),
            ),
            'section' => 'cowboy_footer_options'
        ));


        $wp_customize->add_setting('cowboy_footer_layout', array(
            'default' => '3,3,3,3',
            'transport' => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
            'validate_callback' => 'cowboy_validate_footer_layout'
            
        ));

        $wp_customize->add_control('cowboy_footer_layout', array(
            'type' => 'text',
            'label' => esc_html__( 'Footer Layout', 'cowboy'),
            'section' => 'cowboy_footer_options',
        ));


    }


    add_action( 'customize_register', '_themaname_customize_register');

    function cowboy_sanitize_site_info($input){
        $allowed = array('a'=> array(
            'href' => array(),
            'title' => array()
        ));
        return wp_kses( $input, $allowed);
    } 
    
    function cowboy_sanitize_footer_bg($input){
        $valid = array(
            'light',
            'dark'
        );
        if(in_array($input, $valid, true)){
            return $input;
        }
        return 'dark';
    }   

    function cowboy_validate_footer_layout( $validity, $value) {
        if(!preg_match('/^([1-9]|1[012])(,([1-9]|1[012]))*$/', $value)) {
            $validity->add('invalid_footer_layout', esc_html__( 'Footer layout is invalid', 'cowboy' ));
        }
        return $validity;
    }



?>