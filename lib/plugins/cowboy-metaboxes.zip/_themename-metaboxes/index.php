<?php
/*
Plugin Name: cowboy metaboxes
Plugin URI: 
Description: Adding Metaboxes for cowboy
Version: 1.0.0
Author: Jarldude
Author URI: 
License: GPL2
Text Domain: cowboy-metaboxes
Domain Path: /languages
*/

if( !defined('WPINC') ){
    die;
}

include_once('includes/metaboxes.php');
include_once('includes/enqueue-assets.php');