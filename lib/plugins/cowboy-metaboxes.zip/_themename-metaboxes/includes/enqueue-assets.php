<?php


function cowboy_metaboxes_admin_scripts() {


    global $pagenow;
    if($pagenow !== 'post.php') return;

    wp_enqueue_script( 'cowboy-metaboxes-admin-scripts', plugins_url(
    'cowboy-metaboxes/dist/assets/js/admin.js'), array('jquery'), '1.0.0', true);

    wp_enqueue_style( 'cowboy-metaboxes-admin-stylesheet', plugins_url(
        'cowboy-metaboxes/dist/assets/css/admin.css'), array(), '1.0.0', 'all');
}
add_action('admin_enqueue_scripts', 'cowboy_metaboxes_admin_scripts');

